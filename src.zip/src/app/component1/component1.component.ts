import { Component } from '@angular/core';

@Component({
  selector: 'app-component1',
  templateUrl: './component1.component.html',
  styleUrls: ['./component1.component.css']
})
export class Component1Component {
  userText: string = ''; // Property to store user input

  printToConsole() {
    console.log(this.userText); // Print user input to console
  }
}
